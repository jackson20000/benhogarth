<body>
    <!-- header -->
    <header role="header">
        <!--<div class="container head_logo">-->
            <!-- logo -->
            <!--<div>-->
            <!--    <a href="<?php echo base_url()?>homeweb" title="Benhogarth"><img src="<?php echo base_url()?>assets/frontend/images/logo.png" title="Benhogarth" alt="Benhogarth"-->
            <!--            style="height:60px" /></a>-->
            <!--</div>-->
            <!-- logo -->
            <!-- nav -->
            <!--<nav role="header-nav" class="navy">-->
            <!--    <ul>-->
            <!--        <li class="nav-active"><a href="<?php echo base_url()?>homeweb" title="Home">Home</a></li>-->
                    <!--<li><a href="<?php echo base_url()?>homeweb/about" title="Home">About</a></li>-->
                    <!--<li><a href="<?php echo base_url()?>homeweb/discography" title="Discography">Discography</a></li>-->
            <!--        <li><a href="<?php echo base_url()?>homeweb/booking" title="Artists">Booking</a></li>-->
            <!--         <li><a href="<?php echo base_url()?>homeweb/upload" title="Artists">Upload</a></li>-->
                    <!-- <li><a href="#contact" title="Contact">Contact</a></li> -->
            <!--    </ul>-->
            <!--</nav>-->
            <!-- nav -->
        <!--</div>-->
    </header>
    <!-- header -->
