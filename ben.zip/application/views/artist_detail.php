
    <div class="banner">
        <div class="banner_bg" style="background: linear-gradient(rgba(10,20,30,0.8),rgba(10,20,30,0.3),rgba(10,20,30,0.5)),no-repeat top 58% center/cover url(<?php echo $artistdetail[0]['image'] ?>);">                 
                  <div class="art_banner">
                     <p>Featured Artist</p>
                    <h1><?php echo $artistdetail[0]['name'] ?></h1>
                  </div>            
            </div>           
        </div>
        
        <div class="container">
            <div class="disc_content">
            <h2>MORE BY <?php echo $artistdetail[0]['name'] ?></h2>
            <h3><b>MIXED BY BEN</b></h3>
            <hr class="disc">
            </div>
            <div class="disc_img">
                <ul class="disc_img_list">
                    <li>
                        <img src="<?php echo base_url()?>assets/frontend/images/1.jpg" alt="" >
                        <div style="margin-top:10px;">
                            <p>2018</p>
                            <h4>fghdfh</h4>
                            <p>rktguwr</p>
                        </div>
                    </li>
                    <li>
                        <img src="<?php echo base_url()?>assets/frontend/images/1.jpg" alt="" >
                         <div style="margin-top:10px;">
                            <p>2018</p>
                            <h4>fghdfh</h4>
                            <p>rktguwr</p>
                        </div>
                    </li>
                    <li>
                        <img src="<?php echo base_url()?>assets/frontend/images/1.jpg" alt="" >
                         <div style="margin-top:10px;">
                            <p>2018</p>
                            <h4>fghdfh</h4>
                            <p>rktguwr</p>
                        </div>
                    </li>
                    <li>
                        <img src="<?php echo base_url()?>assets/frontend/images/1.jpg" alt="" >
                         <div style="margin-top:10px;">
                            <p>2018</p>
                            <h4>fghdfh</h4>
                            <p>rktguwr</p>
                        </div>
                    </li>
                    <li>
                        <img src="<?php echo base_url()?>assets/frontend/images/1.jpg" alt="" >
                         <div style="margin-top:10px;">
                            <p>2018</p>
                            <h4>fghdfh</h4>
                            <p>rktguwr</p>
                        </div>
                    </li>
                    <li>
                        <img src="<?php echo base_url()?>assets/frontend/images/1.jpg" alt="" >
                         <div style="margin-top:10px;">
                            <p>2018</p>
                            <h4>fghdfh</h4>
                            <p>rktguwr</p>
                        </div>
                    </li>
                </ul>
                
            </div>
        </div>
     
    </div>
