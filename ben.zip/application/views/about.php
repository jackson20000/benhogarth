
<div class="about_section">
  <div class="sewl-about-me" style="background-image: url('<?php echo base_url()?>assets/frontend/images/headshot.jpg');">
    <div class="about-me-wrap">
      <div class="container">
        <div class="row">
          <div class="about-inner-wrap">
            <div class="vertical-scrollbox mCustomScrollbar _mCS_1 mCS-autoHide"><div id="mCSB_1" class="mCustomScrollBox mCS-light mCSB_vertical mCSB_inside" style="max-height: none;" tabindex="0"><div id="mCSB_1_container" class="mCSB_container" style="position: relative; top: 0px; left: 0px;" dir="ltr">
      				<div class="vc_row wpb_row vc_row-fluid sewl-dhav-dotted"><div class="wpb_column vc_column_container text-left vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	       <div class="wpb_text_column wpb_content_element ">
		     <div class="wpb_wrapper">
			
         <div class="about-info-list ">
              
              <p style="color: #eeeeee;">Ben Hogarth is a recording, mixing, mastering engineer. His interest in music began at a young age in the small state of South Dakota. After growing up playing drums and piano, he ran sound for his dad’s church and fell in love with operating sound boards and the art of sound. From there, he pursued his passion in music and audio and attended McNally Smith College of Music, where he graduated in the Spring of 2015 with a Bachelor of Science in Music Production.</p>
         </div>

    <br>
        <div class="about-info-list ">
             
              <p style="color: #eeeeee; "> Ben has over seven years of experience working in commercial studios in the Twin Cities and Los Angeles area, including The Hideaway Studio, iHeart Media, The Boom Boom Room, Paramount Studios, Conway Studios, Record Plant, Westlake Studios, Glenwood Studios, No Excuses/Interscope Studios, No Name Studios, Blackbird Studios, and many more. He has also worked as Playback Engineer for Jason Derulo over the past two years, working shows in 20+ countries around the world.</p>
       </div>

<br>
      <div class="about-info-list ">
             
              <p style="color: #eeeeee; "> Over time, Ben has worked with artists and bands such as Jason Derulo, Chris Brown, Florida Georgia Line, DNCE, T.I., Omarion, Austin Mahone, T-Pain, Pia Mia, Kid Ink, Jeremih, King Los, 21 Savage, SZA, Travis Scott, ASAP Ferg, ASAP Rocky, Ty Dolla $ign, CL, Lukas Nelson, Wale, Joey Bada$$, Ashlee Simpson, Evan Ross, DJ White Shadow, Lil Bibby, G Herbo, Waka Flocka Flame, Hitmaka, Arin Ray, Syph, Verse Simmonds, Leon Thomas, Jovanie, Raury, Keith Ape, Chaz French, Chris Webby, Jocko Sims, Ricky Hil, Mario, Trevor Jackson, Michael Baker, American Authors, Sam Hunt, Neon Trees, O.A.R., Delta Rae, Lauren Becker and many others. On radio, he has also radio broadcasted for the Minnesota Vikings.</p>
       </div>
   


		  </div>
	 </div>
</div></div></div></div>
            </div><div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-light mCSB_scrollTools_vertical" style="display: block;"><div class="mCSB_draggerContainer" style=""><div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 30px; display: block; height: 27px; max-height: 168px; top: 0px;"><div class="mCSB_dragger_bar" style="line-height: 30px;"></div></div><div class="mCSB_draggerRail"></div></div></div></div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  
